<!DOCTYPE HTML>

<html lang="en">

<head>

<title>Personal Finance - Budgeting System</title>

<style>


html {
	
	 background: url(https://images.pexels.com/photos/908288/pexels-photo-908288.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500) no-repeat center fixed; 
	 background-size: cover;
}
 #dashboard_title {

	background-color : #4c63bd;
	height: 60px;
	font-size: 300%;
	padding: 20px;
	
}


#snapshot {
	
	width : 27%;
	background-color: #4BBD6D;
}
#wrapper {
	
	
	text-align : center;	
}

.content {
  position: fixed;
  bottom: 5;
  background: rgba(0, 0, 0, 0);
  color: #f1f1f1;
  width: 100%;
  padding: 20px;
  text-align:center;
}


#myBtn {
  width: 200px;
  font-size: 18px;
  padding: 10px;
  border: none;
  background: #BD4B9B;
  color: #fff;
  cursor: pointer;
}

#myBtn:hover {
  background: #ddd;
  color: black;
}
	
#radfs_logo{
	
	float: right;
}	
	
</style>

<script></script>

<link rel="stylesheet" type="text/css" href="xxx.css">

<meta charset="UTF-8">
<meta name="description" name="">
<meta name="keywords" name="">
<meta name="author" name="Roger De Four">

<meta name="viewport" content="width=device-width, initial-scale=1">


	
 <!--           ------------------------------------------------------------------------------ START : css  files: * jquery ;* bootstrap ------------------------------------------------------------------------------        	-->
	
	<link rel="stylesheet" type="text/css" href="/bootstrap-3.3.7-dist/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="/bootstrap-3.3.7-dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="/bootstrap-3.3.7-dist/css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="/bootstrap-3.3.7-dist/css/bootstrap-theme.min.css">
	
	
<!--           ------------------------------------------------------------------------------END :   css  files: * jquery ;* bootstrap ------------------------------------------------------------------------------               -->	
	
	<script src="jquery-3.3.1.js"></script>

	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 
 <!--           ------------------------------------------------------------------------------END :  js script files:b * jquery ;* bootstrap ------------------------------------------------------------------------------               -->


</head>

<body>

<div id="wrapper">
	<div id="dashboard_title">Personal Finance Reporting System<img id="radfs_logo" src="RADFS logo.jpg" width=60px height=max-height></div>
	
</div>

<hr>


<div id="snapshot">

<!--<h1>Summary Finance Stats</h1> -->

</div>
<?php
/* 
Developer : Roger De Four
Aim : just an OOP version of my personal budgeting system, done in PHP
Date: 16/02/2019 */
 
 // read article on the include keyword and "importing" php files in multiple directories - http://yagudaev.com/posts/resolving-php-relative-path-problem/
 
 include(dirname(__FILE__) . "/finlib/calculator.php");
 
 /* 
 RADFS: This class - "personal_finance" - was developed to assist me, Roger De Four in the administration of personal finance.
 I included one method that I wrote myself , and that of an external third party  -  http://hywd.info/finlib.phtml
 
 
 
 */
 
 

?>



<div class="content">
<!--
 // the problem of using the a tag to hyperlink onto another .php file was rectified from a KB: https://stackoverflow.com/questions/19421385/html-href-tag-not-redirecting-to-php-file
 -->

 
  <button id="myBtn"><a href="../Financial_Web_App/finlib/financial_calculator.php">Financial Calculator</a></button> 
<!--
  <button id="myBtn">Expense Database</button>
  

  <button id="myBtn">Button0001</button>

  <button id="myBtn">Button0001</button>
 -->
 -->
</div>
</body>

</html>