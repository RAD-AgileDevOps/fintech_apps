18/02/2019
Author: Roger De Four



1.personal finance - budgeting systemv2.php  - the main UI for the personal finance application

2.personal_finance_reporting_system_documentation.odt  - s brief summary of the app