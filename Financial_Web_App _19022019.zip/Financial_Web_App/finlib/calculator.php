<?php
// various financial calculators
// unlike the strict financial equations in Equator these use some assumptions based on real life practices
class Calculator extends personal_finance{
	function __construct() {
		// this will probably accept some settings where a visible calculator should be displayed
		// and with what design
	}
	
	// Home affordability calculator
	// requires the following $input array:
	// "tax" : Annual property taxes
	// "insurance" : Annual insurance
	// "income_per_period" : Gross annual income
	// "monthly_debt" : Monthly debt 
	// "interest" : Mortgage loan rate
	// "downpayment": Downpayment amount
	// Output array explanation:
	// "min_price" : Minimum house price (conservative)
	// "max_price" : Minimum house price (aggressive)
	// "min_loan" : Loan amount (conservative)
	// "max_loan" : Loan amount (aggressive)
	// "min_payment" : Monthly mortgage payment (conservative)
	// "max_payment" : Monthly mortgage payment (aggressive)
	// "taxes_and_insurance" : Taxes and insurance
	// "min_total" : Total monthly payment (conservative)
	// "max_total" : Total monthly payment (aggressive)
	function home_affordability($input) {
		// assume
		$min_pti = 0.28;
		$max_pti = 0.33;
		$loan_life = 30;
		$frequency = 12;
		$min_dti = 0.36;
		$max_dti = 0.38;
		$periods = $loan_life * $frequency;		
		
		// taxes and insurance per period
		$taxes = ($input['tax'] + $input['insurance']) / $frequency;
		$periodic_income = $input['annual_income'] / $frequency;
		
		 // lower level monthly payment
		 $min_total = $periodic_income * $min_pti;
		 $positive = $periodic_income * $min_dti - $input['monthly_debt']; 
		 
		 if($positive < $min_total) {
		 		$min_limit = "debt";
		 		$min_total = $positive;
		 } else $min_limit = "income";
		 
		 // upper level monthly payment
		 $max_total = $periodic_income * $max_pti;
		 $positive = $periodic_income * $max_dti - $input['monthly_debt'];
		 if($positive < $max_total) {
		 		$max_limit = "debt";
		 		$max_total = $positive;
		 } else $max_limit = "income";
		 
		 // get min and max loan bank will give
		 $min_pmt = $min_total - $taxes;
		 $max_pmt = $max_total - $taxes;
		 $period_interest = $input['interest'] / ($frequency * 100); 
		 $discount_f = (pow(1 + $period_interest, $periods) - 1) 
		 	/ ($period_interest * pow(1 + $period_interest, $periods) );
		 	
		 $min_loan = $min_pmt * $discount_f;	 
		 $max_loan = $max_pmt * $discount_f;
		 $min_price = $min_loan + $input['downpayment'];
		 $max_price = $max_loan + $input['downpayment'];
		 
		 // return result array
		 return array( "min_price" => $min_price, "min_loan" => $min_loan, "min_payment" => $min_pmt,
		 	"taxes_and_insurance"=> $taxes, "min_total" => $min_total, "min_limit" => $min_limit,
		 	"max_price" => $max_price, "max_loan" => $max_loan, "max_payment" => $max_pmt, 
		 	"max_total" => $max_total, "max_limit" => $max_limit);		 
	} // end home_affordability
	
		
	// monthly mortgage payment calculator
	// requires the following $input array:
	// "years" - loan term in years
	// "interest" - loan interest
	// "loan_amount" - loan amount
	// "annual_tax" - anual tax
	// "annual_insurance" - annual insurance
	// Returns array:
	// "monthly_principal" - Monthly Principal + Interest
	// "monthly_tax" - Monthly tax
	// "monthly_insurance" - Monthly insurance
	// "total" - Total monthly payment
	function mortgage_payment($input) {
		$mi = $input['interest'] / 1200;
		$base = 1;
		$mbase = 1 + $mi;
		for($i=0; $i < $input['years'] * 12; $i++) {
			$base = $base * $mbase;
		}	
		
		$principal = $input['loan_amount'] * $mi / (1 - 1/$base);
		$monthly_tax = $input['annual_tax']/12;
		$monthly_insurance = $input['annual_insurance']/12;
		
		$total = $principal + $monthly_tax + $monthly_insurance;
		
		return array("monthly_principal" => $principal, "monthly_tax" => $monthly_tax, 
			"monthly_insurance" => $monthly_insurance, "total" => $total);
	}
	
	// 	 calculator
	// requires the following $input array:
	// "principal" - the current principal
	// "addition" - pre-retirement addition
	// "growyears" - years to grow
	// "rate" - grow rate
	// "pyears" - years to pay out
	// "prate" - in retirement grow rate
	function simple_retirement($input) {
		// calculate the basic investment
		$future_value = $this -> future_value($input['principal'], $input['rate']/100, $input['growyears']);
		$g_series = $this->g_series(1+$input['rate']/100, 1, $input['growyears']);		
		$basic = $future_value + $input['addition'] * $g_series;
				
		// annual retirement income
		$annuity_payout = $this->annuity_payout($basic, $input['prate']/100, $input['pyears']);	
		return array("annual_retirement_income"=>number_format($annuity_payout, 2));	 
	}
	
	// helpers below
	function nval($value,$d=null,$min=null,$max=null) {
		if(!is_numeric($value)) $value = 0;

		if ($d) {
			$decimal = pow(10, $d);
			$value = round($value * $decimal) / $decimal;
		}
		if ($min and $value < $min) $value = $min;
		if ($max and $value > $max) $value = $max;
		return $value;
	}
	
	// future value of money
	function future_value($principal, $rate, $periods) {
		//echo $principal."-".$rate."-".$periods."<br>";
		
		$future_value = $principal * pow(1 + $rate, $periods);
		return $future_value;
		//echo 'Hello World'. $future_value; // added by RADFS (17/02/19)
	}
	
	
	function future_value2($principal, $rate, $periods) {
		
	
		//echo $principal."-".$rate."-".$periods."<br>";
		
		
			// an  amended method - used for my example  {17/02/2019}
		$future_value = $principal * pow(1 + $rate, $periods);
		
		
		
		//-----------------------------------------------
		$fmt_principal = new NumberFormatter( 'en_US', NumberFormatter::CURRENCY );
		$fmt = new NumberFormatter( 'en_US', NumberFormatter::CURRENCY );
		echo 'The future value of investment '.$fmt_principal->formatCurrency($principal, "USD")."\n".' at rate of ' .$rate.''.' over investment period of ' .$periods.' years is: ' .$fmt->formatCurrency($future_value, "USD")."\n";
			
		//-----------------------------------------------
		//return $future_value;
		//echo 'Hello World'. $future_value; // added by RADFS (17/02/19)
	}
	
	
	// geom series
	function g_series($rrate, $m, $periods) {
		$amount = 0;
		if ($rrate == 1) $amount = $periods + 1;
		else $amount = (pow($rrate, $periods+1) - 1) / ($rrate - 1); 
		if ($m >= 1) $amount -= $this->g_series($rrate,0,$m-1);
		return $amount;
	}
	
	// calculate annuity payout
	function annuity_payout($principal, $pay_rate, $pay_years) {		
		$payout = $this->future_value($principal, $pay_rate, $pay_years -1) / $this->g_series(1+$pay_rate, 0, $pay_years - 1);
		return $payout;
	}
	
	// -------------------------------------------------------------------------------------------------------------
	/*  RADFS note:
			proof of concept test function to ensure the 'include' and 'DIR' technique works fine { 17/02/2019}
	*/
	
	function radfs_hwd(){
	
		echo "Hello Roger";

		}
		// -------------------------------------------------------------------------------------------------------------
		
		
	
		
		
		
		
		
		
		
		
		
		
	
}




class  personal_finance  {
	
	
	function ttec_estimate($input){
		
				
		$Level1 = 0.26 ;  //the first band rate - TTEC units used
		$Level2 = 0.32; //the second band rate - TTEC units used
		 $Level3 = 0.37; //the second band rate - TTEC units used
		 $VATRate = 1.125;// the Vat rate applied to the total cost

		$Band1 = 400; // the first tier used by TTEC
		$Band2 = 600;  // the second tier used by TTEC
		$Band3 = 1000;  // the third tier used by TTEC
		
		
		$UnitsUsedInPeriod;
		$TotalCost_L1;
		$TotalCost_L2;
		$TotalCost_L3;

		$StartReading = $input['StartReading'];
		$EndReading = $input['EndReading'];
			$UnitsUsedInPeriod = ($EndReading - $StartReading);

		if ($UnitsUsedInPeriod <= $Band1)
			{
				$TotalCost_L1 =  ($UnitsUsedInPeriod * $Level1) * $VATRate;
				// echo 'The estimated electricity cost is: '.' '. $TotalCost_L1;
				$fmt_tot_cost_L1 = new NumberFormatter( 'en_US', NumberFormatter::CURRENCY );
				//echo $fmt_tot_cost_L1->formatCurrency($TotalCost_L1, "USD")."\n";

			}

		else if ($UnitsUsedInPeriod > $Band1 & $UnitsUsedInPeriod <= $Band3)

			{	
				$TotalCost_L2 = (($Band1 * $Level1) + ($UnitsUsedInPeriod - $Band1 ) * $Level2)  * $VATRate ;
				// echo 'The estimated electricity cost is: '.' '. $TotalCost_L2 ;
				$fmt_tot_cost_L2 = new NumberFormatter( 'en_US', NumberFormatter::CURRENCY );
				//echo $fmt_tot_cost_L2->formatCurrency($TotalCost_L2, "USD")."\n";
			}

		else if ($UnitsUsedInPeriod > $Band3 )
			{
				$TotalCost_L1 =  ($UnitsUsedInPeriod * $Level1) * $VATRate;
				$TotalCost_L2 = (($Band1 * $Level1) + ($UnitsUsedInPeriod - $Band1 ) * $Level2)  * $VATRate ;
				$TotalCost_L3 = (($Band1 * $Level1) + ($Band2 * $Level2)  +
				//$TotalCost_L3 = ($TotalCost_L1 + 	$TotalCost_L2  +
				(($UnitsUsedInPeriod - $Band3) * $Level3)) * $VATRate ;
				//echo 'The estimated electricity cost is: '.' '. $TotalCost_L3 ;
				$fmt_tot_cost_L3 = new NumberFormatter( 'en_US', NumberFormatter::CURRENCY );
				// echo 'The estimated electricity cost is: '.' '. $fmt_tot_cost_L3->formatCurrency($TotalCost_L3, "USD")."\n" ;
				
				
				// echo '<b style="color:red;">My Example</b>';
			}

				return array("Level1_cost" => strval($TotalCost_L1) , "Level2" =>strval($TotalCost_L2) , "Level3" => strval($TotalCost_L3) );
			
		}

	function travel_cost ($days_per_week, $num_of_weeks ,$average_travel_cost ){
		
			$expected_travel_cost = $days_per_week * $num_of_weeks *$average_travel_cost;
			echo  'The budgeted travel cost for the period: '.$days_per_week .' '.' days pers week, at average cost of '.' $'.$average_travel_cost.
			' for '.$num_of_weeks.' '. ' weeks entered is '.' $'. $expected_travel_cost .'<br/>' ;
	}

}
/* 
$ttec_costing =   new personal_finance ();
echo $ttec_costing->ttec_estimate(16960, 18572).'<br/><br/>';

$expected_income = new personal_finance ();


echo $expected_income->future_value2(10000, .05, 10).'<br/><br/>' ;

$budgeted_travel_cost = new personal_finance() ;
echo $budgeted_travel_cost->travel_cost(3,8,40).'<br/><br/>';

 */
?>