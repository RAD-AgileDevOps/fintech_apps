// Javascript quest - formating date - got andwer from stack  overflow
// https://stackoverflow.com/questions/28477304/format-input-from-m-d-yyyy-to-yyyymmdd

function formatDate(input_date) {
  // format from M/D/YYYY to YYYYMMDD
  
  // create variable for the old date that needs reformatting
  var prev_date_formatting = String(input_date).split('/');
  
  //concatenate the date in new format after use of indec num
  if (prev_date_formatting[0].length==1)prev_date_formatting[0]='0'+prev_date_formatting[0];
  if (prev_date_formatting[1].length==1)prev_date_formatting[1]='0'+prev_date_formatting[1];
  
  //assign reformatted date to new variable
  var date_newly_formatted = [prev_date_formatting[2], prev_date_formatting[0], prev_date_formatting[1]];
  return date_newly_formatted.join('');
}

