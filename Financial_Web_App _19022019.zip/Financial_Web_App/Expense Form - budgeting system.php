<!DOCTYPE HTML>

<html lang="en">

<head>

<title>Personal Expenses</title>

<style>
body {
	
	color: #FF2200;
	background-color:#C0EA8F;
}
.container {
  width: 500px;
  clear: both;
 
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;

  
}

.container input {
  width: 100%;
  text-align: center;
	 <!--clear: both -->
}</style>

<script></script>

<link rel="stylesheet" type="text/css" href="xxx.css">

<meta charset="UTF-8">
<meta name="description" name="">
<meta name="keywords" name="">
<meta name="author" name="Roger De Four">

</head>

<body>
<?php

?>
	<div class="container">
		<form>

			<!-- // <fieldset> -->
					<legend style="color:#a200ff;">Personal Expenses</legend> <br/> <br/>
					<label for="BudgetCategory">Budget Category:</label>
					<input type="text" name="budget_cat" id="user-name"> <br/>
					<label for="purch-date">Purchase Date:</label>
					<input type="text" name="purchase_date" id="user-pwd">  <br/>
					<label for="BudgetCategory">Description:</label>
					<input type="text" name="budget_cat" id="user-name"> <br/>
					<label for="val_spend">Amount Spent:</label>
					<input width=25px 	type="text" name="amount_spent" id="user-pwd">  <br/>
			  <!-- </fieldset>  -->
			  
		</form>
	</div>
</body>

</html>