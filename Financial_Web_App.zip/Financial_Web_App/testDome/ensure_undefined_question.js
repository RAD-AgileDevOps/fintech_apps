// https://stackoverflow.com/questions/44874410/javascript-function-should-throw-an-error-if-called-without-arguments-or-an-argu
//RADFS : this is solution as stated on stack overflow
//dd: 17/02/2019


function ensure(value) {
  if(value === undefined) {
    throw new Error('no arguments');
  }

  return value;
}

console.log(ensure('text'));
console.log(ensure([0,1,2,3]));
console.log(ensure());